document.addEventListener('DOMContentLoaded', () => {
  // Guard if the template script wasn’t included yet
  if (!window.appUrls || !window.appUrls.ajaxMatterOptions) {
    console.error('ajaxMatterOptions URL not provided via window.appUrls');
    return;
  }

  const client = document.getElementById('id_inv_client');
  const matter = document.getElementById('id_inv_matter');
  const ajaxUrl = window.appUrls.ajaxMatterOptions;

  if (!client || !matter) return;

  const params = new URLSearchParams(window.location.search);
  const currentClient = params.get('client') || '';
  const currentMatter = params.get('matter') || '';

  function safeSelectOption(selectEl, value) {
    if (!value) return;
    try {
      const opt = selectEl.querySelector(`option[value="${CSS.escape(value)}"]`);
      if (opt) opt.selected = true;
    } catch {
      // CSS.escape may not exist in very old browsers; ignore gracefully
      const opts = [...selectEl.options];
      const found = opts.find(o => o.value === value);
      if (found) found.selected = true;
    }
  }

  function setURLWithoutReload(clientVal, matterVal) {
    const qs = new URLSearchParams();
    if (clientVal) qs.set('client', clientVal);
    if (matterVal) qs.set('matter', matterVal);
    const newUrl = `${location.pathname}${qs.toString() ? `?${qs}` : ''}`;
    history.replaceState(null, '', newUrl);
  }

  async function loadMatters(cid, selectValue = '') {
    if (!cid) {
      matter.innerHTML = '<option value="">— Select matter —</option>';
      setURLWithoutReload('', '');
      return;
    }
    matter.disabled = true;
    matter.innerHTML = '<option value="">Loading matters…</option>';

    try {
      const r = await fetch(`${ajaxUrl}?client=${encodeURIComponent(cid)}`, {
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Accept': 'text/html'
        }
      });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const optionsHtml = await r.text();
      matter.innerHTML = optionsHtml || '<option value="">No matters found</option>';
      matter.disabled = false;
      if (selectValue) safeSelectOption(matter, selectValue);
    } catch (err) {
      console.error('Failed to load matters:', err);
      matter.innerHTML = '<option value="">Error loading matters</option>';
      matter.disabled = true;
    }
  }

  // Initial populate (supports preselected client/matter via querystring)
  const initialClient = client.value || currentClient;
  if (initialClient) {
    loadMatters(initialClient, currentMatter);
    setURLWithoutReload(initialClient, currentMatter);
  }

  client.addEventListener('change', e => {
    const cid = e.target.value || '';
    loadMatters(cid, '');
    setURLWithoutReload(cid, '');
  });

  matter.addEventListener('change', e => {
    const cid = client.value || '';
    const mid = e.target.value || '';
    setURLWithoutReload(cid, mid);
  });
});
